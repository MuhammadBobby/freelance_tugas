<?php include 'header.php'; ?>
	<div class="container">
		<div class="panel-body">
	<h2>SELAMAT DATANG DI HALAMAN UTAMA WEB SPP</h2>
	<H5>SMK AKP GALANG</H5>

</div>
</div>




 
<?php include 'footer.php'; ?>