<?php
$konek = mysqli_connect('localhost','root','','sppsekolah1');

?>